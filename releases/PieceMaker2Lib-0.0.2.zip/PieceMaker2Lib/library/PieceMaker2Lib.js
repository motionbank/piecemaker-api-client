/**
 *	PieceMaker API client (JavaScript version) for Motion Bank.
 *
 *	See: 
 *	  http://piecemaker.org
 *	  http://motionbank.org
 *	  https://github.com/fjenett/piecemaker-api-client
 *
 *	Version: 0.0.2, build: 222
 */
 var PieceMakerApi=function(){var e=void 0,d=void 0,g=function(){},i=function(a,b,c,j,e){jQuery.ajax({url:b,type:c,dataType:"json",data:j,context:a,success:e,error:function(a){if(d&&"piecemakerError"in d&&"function"==typeof d.piecemakerError)d.piecemakerError(a);else throw a;}})},h=function(a,b){i(a,b.url,"get",null,b.success)},f=function(){var a=arguments[0];1==arguments.length&&"object"==typeof a?(d=a.context||{},e=a.baseUrl||"http://localhost:3000"):(1<=arguments.length&&"object"==typeof arguments[0]&&
(d=arguments[0]),2<=arguments.length&&"string"==typeof arguments[1]&&(e=arguments[1]))};f.prototype.getGroup=function(a,b){var c=b||g;h(this,{url:e+"/event_group/"+a,success:function(a){c.call(d||b,a)}})};f.prototype.listGroups=function(a){var b=a||g;h(this,{url:e+"/event_groups",success:function(c){b.call(d||a,c)}})};f.prototype.listGroupEvents=function(a,b){var c=b||g;h(this,{url:e+"/event_group/"+a+"/events",success:function(a){c.call(d||b,a)}})};f.prototype.getVideo=function(a,b){var c=b||g;h(this,
{url:e+"/event/"+a,success:function(a){c.call(d||b,a)}})};f.prototype.getEvent=function(a,b){var c=b||g;h(this,{url:e+"/event/"+a,success:function(a){c.call(d||b,a)}})};f.prototype.createEvent=function(a,b){var c=b||g;i(this,e+"/event","post",a,function(a){c.call(d||b,a)})};f.prototype.saveEvent=function(a,b,c){var f=c||g;i(this,e+"/event/"+a,"put",b,function(a){f.call(d||c,a)})};f.prototype.deleteEvent=function(a,b){var c=b||g;"object"===typeof a&&"id"in a&&(a=a.id);i(this,e+"/event/"+a,"delete",
null,function(a){c.call(d||b,a)})};f.prototype.createCallback=function(){if(1==arguments.length)return d[arguments[0]];if(2==arguments.length)return arguments[0][arguments[1]];throw"PieceMakerAPI error: wrong number of arguments";};return f}();if(!("$"in this))var $={ajax:function(){}};