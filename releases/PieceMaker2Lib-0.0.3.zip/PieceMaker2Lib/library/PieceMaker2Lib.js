/**
 *	Piecemaker 2 API client (JavaScript version) for Motion Bank.
 *
 *	See: 
 *	  https://github.com/motionbank/piecemaker2
 *	  https://github.com/motionbank/piecemaker-api-client
 *
 *	Project:
 *	  http://piecemaker.org
 *	  http://motionbank.org
 *
 *	Version: 0.0.3, build: 429
 */
 var PieceMaker2Api=function(){var f=function(){},i=function(a,e,d,h,c){b.api_key&&(h&&!("token"in h)?h.token=b.api_key:h||(h={token:b.api_key}));var f=(new Date).getTime();jQuery.ajax({url:e+".json",type:d,dataType:"json",data:h,context:a,success:function(){arguments&&(arguments[0]&&typeof arguments[0]==="object"&&!("queryTime"in arguments[0]))&&(arguments[0].queryTime=(new Date).getTime()-f);c.apply(a,arguments)},error:function(a){if(b.context&&"piecemakerError"in b.context&&typeof b.context.piecemakerError==
"function")b.context.piecemakerError(a);else throw a;}})},g=function(a,b){i(a,b.url,"get",b.data,b.success)},b,c=function(){this.context=this.api_key=this.baseUrl=void 0;var a=arguments[0];if(1==arguments.length&&"object"==typeof a)this.context=a.context||{},this.api_key=a.api_key||!1,this.baseUrl=a.baseUrl||"http://localhost:3000";else if(1<=arguments.length&&"object"==typeof arguments[0]&&(this.context=arguments[0]),2<=arguments.length&&"string"==typeof arguments[1]&&(this.baseUrl=arguments[1]),
3<=arguments.length&&"string"==typeof arguments[2])this.api_key=arguments[2];if(!this.api_key)throw"PieceMaker2API: need an API_KEY for this to work";b=this};c.prototype.getUsers=function(a){var e=a||f;g(this,{url:b.baseUrl+"/users",success:function(d){e.call(b.context||a,d)}})};c.prototype.createUser=function(){};c.prototype.getUser=function(a,e){var d=e||f;g(this,{url:b.baseUrl+"/user/"+a,success:function(a){d.call(b.context||e,a)}})};c.prototype.updateUser=function(){};c.prototype.deleteUser=function(){};
c.prototype.listGroups=function(a){var e=a||f;g(this,{url:b.baseUrl+"/groups",success:function(d){e.call(b.context||a,d)}})};c.prototype.createGroup=function(){};c.prototype.getGroup=function(a,e){var d=e||f;g(this,{url:b.baseUrl+"/group/"+a,success:function(a){d.call(b.context||e,a)}})};c.prototype.updateGroup=function(){};c.prototype.deleteGroup=function(){};c.prototype.getGroupUsers=function(a,e){var d=e||f;g(this,{url:b.baseUrl+"/group/"+a+"/users",success:function(a){d.call(b.context||e,a)}})};
c.prototype.listEvents=function(a,e){var d=e||f;g(this,{url:b.baseUrl+"/group/"+a+"/events",success:function(a){d.call(b.context||e,a)}})};c.prototype.listEventsOfType=function(a,e,d){var c=d||f;g(this,{url:b.baseUrl+"/group/"+a+"/events",data:{type:e},success:function(a){c.call(b.context||d,a)}})};c.prototype.listEventsWithFields=function(a,e,d){var c=d||f;g(b,{url:b.baseUrl+"/group/"+a+"/events",data:e,success:function(a){c.call(b.context||d,a)}})};c.prototype.createEvent=function(a,e,d){var c=
d||f;i(this,b.baseUrl+"/group/"+a+"/event","post",e,function(a){c.call(b.context||d,a)})};c.prototype.getEvent=function(a,e,d){var c=d||f;g(b,{url:b.baseUrl+"/group/"+a+"/event/"+eventId,success:function(a){c.call(b.context||d,a)}})};c.prototype.updateEvent=function(a,c,d){var h=d||f;i(this,b.baseUrl+"/group/"+groupId+"/event/"+a,"put",c,function(a){h.call(b.context||d,a)})};c.prototype.deleteEvent=function(a,c){var d=c||f;"object"===typeof a&&"id"in a&&(a=a.id);i(this,b.baseUrl+"/group/"+groupId+
"/event/"+a,"delete",null,function(a){d.call(b.context||c,a)})};c.prototype.getSystemTime=function(a){var c=(new Date).getTime(),d=a||f;g(this,{url:b.baseUrl+"/system/utc_timestamp",success:function(f){var g=(new Date).getTime();d.call(b.context||a,{systemTime:(new Date(1E3*parseFloat(f))).getTime(),callDuration:g-c})}})};c.prototype.createCallback=function(){if(1==arguments.length)return this.context[arguments[0]];if(2==arguments.length)return arguments[0][arguments[1]];throw"PieceMakerAPI error: wrong number of arguments";
};return c}();