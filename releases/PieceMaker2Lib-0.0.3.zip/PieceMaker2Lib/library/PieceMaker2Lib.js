/**
 *	Piecemaker 2 API client (JavaScript version) for Motion Bank.
 *
 *	See: 
 *	  https://github.com/motionbank/piecemaker2
 *	  https://github.com/motionbank/piecemaker-api-client
 *
 *	Project:
 *	  http://piecemaker.org
 *	  http://motionbank.org
 *
 *	Version: 0.0.3, build: 420
 */
 var PieceMaker2Api=function(){return PieceMakerApi}();